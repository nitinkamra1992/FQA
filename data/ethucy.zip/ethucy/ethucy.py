import os

import sys
sys.path.append('./')
from data.TrajectoryDataset import TrajectoryDataset
from utils.misc_utils import get_files, get_dirs


data_dir = 'data/ethucy/'
tr_dir = os.path.join(data_dir, 'train')
val_dir = os.path.join(data_dir, 'validation')
te_dir = os.path.join(data_dir, 'test')

dsets = ['biwi_hotel.txt','crowds_zara02.txt', 'crowds_zara03.txt', 'students001.txt', 'students003.txt']

tr_data_files = [os.path.join(tr_dir, filepath) for filepath in dsets]
val_data_files = [os.path.join(val_dir, filepath) for filepath in dsets]
te_data_files = [os.path.join(te_dir, filepath) for filepath in dsets]

def get_dataset(dtype, max_length=20, min_length=5, skip_frames=0, burn_in_steps=8, **kwargs):
    if dtype == 'tr':
        return TrajectoryDataset(tr_data_files, max_length=max_length, skip_frames=skip_frames,
                                 burn_in_steps=burn_in_steps, min_length=min_length, **kwargs)
    elif dtype == 'te':
        return TrajectoryDataset(te_data_files, max_length=max_length, skip_frames=skip_frames,
                                 burn_in_steps=burn_in_steps, min_length=min_length, **kwargs)
    elif dtype == 'val':
        return TrajectoryDataset(val_data_files, max_length=max_length, skip_frames=skip_frames,
                                 burn_in_steps=burn_in_steps, min_length=min_length, **kwargs)
